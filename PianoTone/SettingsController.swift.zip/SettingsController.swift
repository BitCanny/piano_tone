//
//  SettingsController.swift
//  PianoTone
//
//  Created by luv mehta on 04/01/16.
//  Copyright © 2016 luv mehta. All rights reserved.
//

import UIKit

class SettingsController: UIViewController,NIDropDownDelegate,UITextFieldDelegate {
    @IBOutlet    var amplitudeLevelTextField: UITextField?
    @IBOutlet    var timeTextField: UITextField?
      @IBOutlet    var baseView: UIView?
      @IBOutlet    var modeView: UIView?
      @IBOutlet    var levelView: UIView?
      @IBOutlet    var trainingButton: UIButton?
    @IBOutlet    var challengeButton: UIButton?
    @IBOutlet    var easyButton: UIButton?
    @IBOutlet    var hardButton: UIButton?
    @IBOutlet    var pageButton: UIButton?
    @IBOutlet var testKeyButton : UIButton?
    @IBOutlet    var dropDown: NIDropDown?
   
      @IBOutlet    var bgScrollView: UIScrollView?
    var isChanged : Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        let defaults = NSUserDefaults.standardUserDefaults()
        let mode  = defaults.objectForKey("Mode") as! String
        let level = defaults.objectForKey("Level") as! String
       
        var  totalPage = defaults.integerForKey("totalPage")
        if totalPage <= 0 {
            totalPage = 1
        }
        
        
        if defaults.boolForKey("isUsePreKeys") == true{
            let image = UIImage(named: "chk.png") as UIImage!
            testKeyButton!.setImage(image, forState: .Normal)
        }
        else{
            let image = UIImage(named: "unchk.png") as UIImage!
            testKeyButton!.setImage(image, forState: .Normal)

        }
        
        let ampLevel : Double = defaults.doubleForKey("amplitudeLevel")
        amplitudeLevelTextField?.text = String(format: "%lf", ampLevel)
        pageButton?.setTitle(String(format: "%d",totalPage), forState: .Normal)
        modeView?.layer.masksToBounds = true
        modeView?.layer.borderWidth = 2.0
        modeView?.layer.borderColor = UIColor.whiteColor().CGColor
        
        levelView?.layer.masksToBounds = true
        levelView?.layer.borderWidth = 2.0
        levelView?.layer.borderColor = UIColor.whiteColor().CGColor
        
        pageButton?.layer.masksToBounds = true
        pageButton?.layer.cornerRadius = 4.0
        pageButton?.layer.borderColor = UIColor.whiteColor().CGColor
        
        timeTextField?.text = String(format: "%lf", defaults.doubleForKey( "timerTime"))
        
        for view in (modeView?.subviews)! {
            if let btn = view as? UIButton {
                if (btn.tag == 1 && mode.caseInsensitiveCompare("Training") == NSComparisonResult.OrderedSame) || (btn.tag == 2 && mode.caseInsensitiveCompare("Challenge") == NSComparisonResult.OrderedSame)  {
                let image = UIImage(named: "selradio.png") as UIImage!
                btn.setImage(image, forState: .Normal)
                
                }
               
            }
        }
        for view in (levelView?.subviews)! {
            if let btn = view as? UIButton {
                if (btn.tag == 3 && level.caseInsensitiveCompare("Easy") == NSComparisonResult.OrderedSame) || (btn.tag == 4 && level.caseInsensitiveCompare("Hard") == NSComparisonResult.OrderedSame) {
                    let image = UIImage(named: "selradio.png") as UIImage!
                    btn.setImage(image, forState: .Normal)
                    
                }
                
            }
        }
    }
    func niDropDownDelegateMethod(sender :NIDropDown )->Void {
        let defaults = NSUserDefaults.standardUserDefaults()
        let totalpageStr = pageButton?.titleLabel?.text
        let myNSString = totalpageStr as! NSString
        let pageNo : Int = Int(myNSString.intValue)
        defaults.setInteger(pageNo, forKey: "totalPage")
        
        defaults.synchronize()
        if isChanged == false{
            NSNotificationCenter.defaultCenter().postNotificationName("removeFromUserDefault", object: nil)
            isChanged = true
        }

    self.rel()
    }
    
    func rel( )->Void {
    //    [dropDown release];
    dropDown = nil;
    }
    override func viewDidAppear(animated: Bool) {
        var scrollSize : CGSize = (bgScrollView?.contentSize)!
         scrollSize.height = 380
//        scrollSize.height = (modeView?.frame.size.height)! + (levelView?.frame.size.height)! + 60
        bgScrollView?.contentSize = (baseView?.frame.size)!
        
       


    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func didPageClick(button: UIButton) {
        
        if(dropDown == nil) {
            var f : CGFloat = 200
            
            
            dropDown = NIDropDown.init()
            let numArray : [NSString] = ["1", "2", "3","4", "5", "6","7", "8", "9","10"]
            var imgArray : [UIImage] = []
            for var i = 0; i < 10; ++i{
                
                imgArray.append(UIImage(named: "apple.png")!)
            }
            dropDown?.showDropDown(button, &f, numArray,imgArray, "down")
            
            dropDown!.delegate = self;
        }
        else {
            dropDown?.hideDropDown(button)
            
            var timer = NSTimer.scheduledTimerWithTimeInterval(0.1, target: self, selector: Selector("removeDropDown"), userInfo: nil, repeats: false)

            
        }
    }
    func removeDropDown() {
        dropDown = nil
        // Something after a delay
    }
    @IBAction func didHardClick(button: UIButton) {
         let defaults = NSUserDefaults.standardUserDefaults()
         defaults.setObject("Hard", forKey: "Level")
        defaults.synchronize()
        let image = UIImage(named: "selradio.png") as UIImage!
        hardButton!.setImage(image, forState: .Normal)
        
        let image1 = UIImage(named: "radio.png") as UIImage!
        easyButton!.setImage(image1, forState: .Normal)
        if isChanged == false{
            NSNotificationCenter.defaultCenter().postNotificationName("removeFromUserDefault", object: nil)
            isChanged = true
        }
        
    }
    @IBAction func didEasyClick(button: UIButton) {
        let defaults = NSUserDefaults.standardUserDefaults()
        defaults.setObject("Easy", forKey: "Level")
        defaults.synchronize()
        let image = UIImage(named: "selradio.png") as UIImage!
        easyButton!.setImage(image, forState: .Normal)
        
        let image1 = UIImage(named: "radio.png") as UIImage!
        hardButton!.setImage(image1, forState: .Normal)
        if isChanged == false{
            NSNotificationCenter.defaultCenter().postNotificationName("removeFromUserDefault", object: nil)
            isChanged = true
        }
        
    }
    @IBAction func didChallengeClick(button: UIButton) {
        
        let defaults = NSUserDefaults.standardUserDefaults()
        defaults.setObject("Challenge", forKey: "Mode")
        defaults.synchronize()
        
        let image = UIImage(named: "selradio.png") as UIImage!
        challengeButton!.setImage(image, forState: .Normal)
        
        let image1 = UIImage(named: "radio.png") as UIImage!
        trainingButton!.setImage(image1, forState: .Normal)
        if isChanged == false{
            NSNotificationCenter.defaultCenter().postNotificationName("removeFromUserDefault", object: nil)
            isChanged = true
        }
        
    }
    @IBAction func didTrainingClick(button: UIButton) {
        
        let defaults = NSUserDefaults.standardUserDefaults()
        defaults.setObject("Training", forKey: "Mode")
        defaults.synchronize()
        
        let image = UIImage(named: "selradio.png") as UIImage!
        trainingButton!.setImage(image, forState: .Normal)
        
        let image1 = UIImage(named: "radio.png") as UIImage!
        challengeButton!.setImage(image1, forState: .Normal)
        if isChanged == false{
            NSNotificationCenter.defaultCenter().postNotificationName("removeFromUserDefault", object: nil)
            isChanged = true
        }
        
    }
 
    @IBAction func didHardKeyClick(button: UIButton) {
         let defaults = NSUserDefaults.standardUserDefaults()
        if defaults.boolForKey("isUsePreKeys") == true{
            let image = UIImage(named: "unchk.png") as UIImage!
            testKeyButton!.setImage(image, forState: .Normal)
            defaults.setBool(false, forKey: "isUsePreKeys")
            defaults.synchronize()
        }
        else{
            let image = UIImage(named: "chk.png") as UIImage!
            testKeyButton!.setImage(image, forState: .Normal)
            defaults.setBool(true, forKey: "isUsePreKeys")
            defaults.synchronize()
        }
        
    }
    @IBAction func didBackClick(button: UIButton) {
        
        self.navigationController?.popViewControllerAnimated(true)
        
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        print("TextField did begin editing method called")
    }
    func textFieldDidEndEditing(textField: UITextField) {
        let defaults = NSUserDefaults.standardUserDefaults()
        print("TextField did end editing method called")
        if textField == amplitudeLevelTextField{
        let actualLevel : Double = defaults.doubleForKey("amplitudeLevel")
        let dbLevelStr = textField.text
            let myNSString : NSString = dbLevelStr as! NSString
        let dbLevel : Double = Double(myNSString.doubleValue)
        if dbLevel <= 0 || dbLevel >= 1{
            textField.text = String(format: "%lf", actualLevel)
            return
        }
        
        defaults.setDouble(dbLevel, forKey: "amplitudeLevel")
        }
        else{
            let actualTime : Double = defaults.doubleForKey("timerTime")
            let timeStr = textField.text
            let myNSString = timeStr as! NSString
            let timerTime : Double = Double(myNSString.doubleValue)
            if timerTime <= 0 {
                textField.text = String(format: "%lf", actualTime)
                return
            }
            
            defaults.setDouble(timerTime, forKey: "timerTime")
   
        }
       
        defaults.synchronize()
        }
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        print("TextField should begin editing method called")
        return true;
    }
    func textFieldShouldClear(textField: UITextField) -> Bool {
        print("TextField should clear method called")
        return true;
    }
    func textFieldShouldEndEditing(textField: UITextField) -> Bool {
        print("TextField should snd editing method called")
        return true;
    }
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        print("While entering the characters this method gets called")
        return true;
    }
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        print("TextField should return method called")
        textField.resignFirstResponder();
        return true;
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
